<div>
    <button class="fs-3 text-primary" wire:click="like(<?php echo e($article->id); ?>)"><i class="fa-solid fa-thumbs-up"></i>(<?php echo e($article->totalLike()); ?>)</button>

    <h3 class="h3 text-black">(<?php echo e($total_comment); ?>) Comment</h3>

    <form wire:submit.prevent="store" class="mb-4">
            <textarea wire:model="body" rows="2" class="form-control <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="tulis komentar anda" ></textarea>
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
            <div class="mt-3 d-grid">
                <button class="btn btn-primary">Kirim</button>
            </div>

    </form>

    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="mb-3">
        <div class="d-flex align-items-start">

            <img src="https://i.pinimg.com/236x/56/2e/be/562ebed9cd49b9a09baa35eddfe86b00.jpg" alt="" class="img-fluid rounded-circle me-3" width="40" height="40">
            <div>
                <div>
                    <span><?php echo e($item->user->name); ?></span>
                    <span><?php echo e($item->created_at); ?></span>
                </div>
                <div>
                    <?php echo e($item->body); ?>

                </div>
                <div>
                    <button class="btn btn-primary" wire:click ="selectReply(<?php echo e($item->id); ?>)">Balas</button>
                    <!--[if BLOCK]><![endif]--><?php if($item->user_id == Auth::user()->id): ?>
                    <button class="btn btn-warning" wire:click="selectEdit(<?php echo e($item->id); ?>)">Edit</button>
                    <button class="btn btn-danger" wire:click="delete(<?php echo e($item->id); ?>)">Hapus</button>
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($edit_comment_id == $item->id): ?>
                    <form wire:submit.prevent="update" class="mb-4 mt-3">
                        <textarea wire:model.defer="body2" rows="2" class="form-control <?php $__errorArgs = ['body2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="tulis komentar anda" ></textarea>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['body2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        <div class="mt-3 d-grid">
                            <button class="btn btn-warning">Update</button>
                        </div>
                    </form>
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($comment_id == $item->id): ?>
                    <form wire:submit.prevent="reply" class="mb-4 mt-3">
                        <textarea wire:model.defer="body2" rows="2" class="form-control <?php $__errorArgs = ['body2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="tulis komentar anda" ></textarea>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['body2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        <div class="mt-3 d-grid">
                            <button class="btn btn-warning">Reply</button>
                        </div>
                    </form>
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
        <!--[if BLOCK]><![endif]--><?php if($item->children): ?>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="d-flex align-items-start ml-4">
            <img src="https://i.pinimg.com/236x/56/2e/be/562ebed9cd49b9a09baa35eddfe86b00.jpg" alt="" class="img-fluid rounded-circle me-3" width="40" height="40">
            <div>
                <div>
                    <span><?php echo e($item2->user->name); ?></span>
                    <span><?php echo e($item2->created_at); ?></span>
                </div>
                <div>
                    <?php echo e($item2->body); ?>

                </div>
                <div>
                    <button class="btn btn-primary" wire:click ="selectReply(<?php echo e($item2->id); ?>)">Balas</button>
                    <!--[if BLOCK]><![endif]--><?php if($item2->user_id == Auth::user()->id): ?>
                    <button class="btn btn-warning" wire:click="selectEdit(<?php echo e($item2->id); ?>)">Edit</button>
                    <button class="btn btn-danger" wire:click="delete(<?php echo e($item2->id); ?>)">Hapus</button>
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($edit_comment_id == $item2->id): ?>
                    <form wire:submit.prevent="update" class="mb-4 mt-3">
                        <textarea wire:model="body2" rows="2" class="form-control <?php $__errorArgs = ['body2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="tulis komentar anda" ></textarea>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['body2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        <div class="mt-3 d-grid">
                            <button class="btn btn-warning">Update</button>
                        </div>
                    </form>
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    <!--[if BLOCK]><![endif]--><?php if($comment_id == $item2->id): ?>
                    <form wire:submit.prevent="reply" class="mb-4 mt-3">
                        <textarea wire:model="body2" rows="2" class="form-control <?php $__errorArgs = ['body2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="tulis komentar anda" ></textarea>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['body2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                        <div class="mt-3 d-grid">
                            <button class="btn btn-warning">Reply</button>
                        </div>
                    </form>
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        <hr>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH /Users/tuderama/Documents/Laravel_Project/crud-admin/resources/views/livewire/comment.blade.php ENDPATH**/ ?>